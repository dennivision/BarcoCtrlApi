﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BarcoCtrlApi;

namespace BarcoClientApp
{
    internal class Program
    {
        try
        {
            // OAuth2 credentials
            var clientId = "your_client_id";
            var clientSecret = "your_client_secret";
            var tokenUrl = "https://10.112.57.0/auth/realms/OCS/protocol/openid-connect/token";

            // Initialize OAuth client
            var oauthClient = new OAuth2Client(clientId, clientSecret, tokenUrl);

            // Base API URL
            var baseUrl = "https://your-api-url";

            // Initialize the API client with the OAuth client
            var apiClient = new BarcoCtrlApiClient(baseUrl, oauthClient);

            // Example: Get API Version
            string apiVersion = await apiClient.GetApiVersionAsync();
            Console.WriteLine("API Version: " + apiVersion);

            // Example: Get Workplaces
            var workplaces = await apiClient.GetWorkplacesAsync();
            foreach (var workplace in workplaces)
            {
                Console.WriteLine($"Workplace: {workplace.Name}, Type: {workplace.Type}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }
}
